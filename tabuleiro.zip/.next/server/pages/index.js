/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./components/CasaTabuleiro/Casa_tabuleiro.module.css":
/*!************************************************************!*\
  !*** ./components/CasaTabuleiro/Casa_tabuleiro.module.css ***!
  \************************************************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"square\": \"Casa_tabuleiro_square__Qjt4M\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0Nhc2FUYWJ1bGVpcm8vQ2FzYV90YWJ1bGVpcm8ubW9kdWxlLmNzcy5qcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL3RhYnVsZWlyby8uL2NvbXBvbmVudHMvQ2FzYVRhYnVsZWlyby9DYXNhX3RhYnVsZWlyby5tb2R1bGUuY3NzPzcxNzIiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gRXhwb3J0c1xubW9kdWxlLmV4cG9ydHMgPSB7XG5cdFwic3F1YXJlXCI6IFwiQ2FzYV90YWJ1bGVpcm9fc3F1YXJlX19RanQ0TVwiXG59O1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/CasaTabuleiro/Casa_tabuleiro.module.css\n");

/***/ }),

/***/ "./components/CasaTabuleiro/CasaTabuleiro.jsx":
/*!****************************************************!*\
  !*** ./components/CasaTabuleiro/CasaTabuleiro.jsx ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ CasaTabuleiro)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Casa_tabuleiro_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Casa_tabuleiro.module.css */ \"./components/CasaTabuleiro/Casa_tabuleiro.module.css\");\n/* harmony import */ var _Casa_tabuleiro_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_Casa_tabuleiro_module_css__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction CasaTabuleiro({ color  }) {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: (_Casa_tabuleiro_module_css__WEBPACK_IMPORTED_MODULE_1___default().square),\n        style: {\n            backgroundColor: color\n        }\n    }, void 0, false, {\n        fileName: \"D:\\\\Nova_pasta\\\\pen_drive\\\\backup\\\\ionic\\\\Jorge\\\\tabuleiro\\\\components\\\\CasaTabuleiro\\\\CasaTabuleiro.jsx\",\n        lineNumber: 6,\n        columnNumber: 9\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0Nhc2FUYWJ1bGVpcm8vQ2FzYVRhYnVsZWlyby5qc3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQWdEO0FBRWpDLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLENBQUNDLENBQUFBLEtBQUssR0FBQyxFQUFDLENBQUM7SUFFM0MsTUFBTSw2RUFDREMsQ0FBRztRQUFDQyxTQUFTLEVBQUVKLDBFQUFhO1FBQUVNLEtBQUssRUFBRSxDQUFDQztZQUFBQSxlQUFlLEVBQUVMLEtBQUs7UUFBQSxDQUFDOzs7Ozs7QUFFdEUsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3RhYnVsZWlyby8uL2NvbXBvbmVudHMvQ2FzYVRhYnVsZWlyby9DYXNhVGFidWxlaXJvLmpzeD9hZjNlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZXMgZnJvbSBcIi4vQ2FzYV90YWJ1bGVpcm8ubW9kdWxlLmNzc1wiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ2FzYVRhYnVsZWlybyh7Y29sb3J9KXtcclxuXHJcbiAgICByZXR1cm4oXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5zcXVhcmV9IHN0eWxlPXt7YmFja2dyb3VuZENvbG9yOiBjb2xvcn19PjwvZGl2PlxyXG4gICAgKTtcclxufSJdLCJuYW1lcyI6WyJzdHlsZXMiLCJDYXNhVGFidWxlaXJvIiwiY29sb3IiLCJkaXYiLCJjbGFzc05hbWUiLCJzcXVhcmUiLCJzdHlsZSIsImJhY2tncm91bmRDb2xvciJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/CasaTabuleiro/CasaTabuleiro.jsx\n");

/***/ }),

/***/ "./components/LinhaTabuleiro/LinhaTabuleiro.jsx":
/*!******************************************************!*\
  !*** ./components/LinhaTabuleiro/LinhaTabuleiro.jsx ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LinhaTabuleiro)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _CasaTabuleiro_CasaTabuleiro__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../CasaTabuleiro/CasaTabuleiro */ \"./components/CasaTabuleiro/CasaTabuleiro.jsx\");\n\n\nfunction LinhaTabuleiro({ lineValue  }) {\n    const colorSet1 = [\n        \"#fff\",\n        \"#000\",\n        \"#fff\",\n        \"#000\",\n        \"#fff\",\n        \"#000\",\n        \"#fff\",\n        \"#000\"\n    ];\n    const colorSet2 = [\n        \"#000\",\n        \"#fff\",\n        \"#000\",\n        \"#fff\",\n        \"#000\",\n        \"#fff\",\n        \"#000\",\n        \"#fff\"\n    ];\n    let keyValue = lineValue * 8;\n    function renderLine(Color, index) {\n        index += keyValue;\n        return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_CasaTabuleiro_CasaTabuleiro__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n            color: Color\n        }, index, false, {\n            fileName: \"D:\\\\Nova_pasta\\\\pen_drive\\\\backup\\\\ionic\\\\Jorge\\\\tabuleiro\\\\components\\\\LinhaTabuleiro\\\\LinhaTabuleiro.jsx\",\n            lineNumber: 14,\n            columnNumber: 13\n        }, this));\n    }\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        style: {\n            display: \"flex\"\n        },\n        children: lineValue % 2 === 0 ? colorSet1.map(renderLine) : colorSet2.map(renderLine)\n    }, void 0, false, {\n        fileName: \"D:\\\\Nova_pasta\\\\pen_drive\\\\backup\\\\ionic\\\\Jorge\\\\tabuleiro\\\\components\\\\LinhaTabuleiro\\\\LinhaTabuleiro.jsx\",\n        lineNumber: 19,\n        columnNumber: 9\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0xpbmhhVGFidWxlaXJvL0xpbmhhVGFidWxlaXJvLmpzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUEwRDtBQUUzQyxRQUFRLENBQUNDLGNBQWMsQ0FBQyxDQUFDQyxDQUFBQSxTQUFTLEdBQUMsRUFBQyxDQUFDO0lBRWhELEtBQUssQ0FBQ0MsU0FBUyxHQUFHLENBQUM7UUFBQSxDQUFNO1FBQUUsQ0FBTTtRQUFFLENBQU07UUFBRSxDQUFNO1FBQUUsQ0FBTTtRQUFFLENBQU07UUFBRSxDQUFNO1FBQUUsQ0FBTTtJQUFBLENBQUM7SUFDbEYsS0FBSyxDQUFDQyxTQUFTLEdBQUcsQ0FBQztRQUFBLENBQU07UUFBRSxDQUFNO1FBQUUsQ0FBTTtRQUFFLENBQU07UUFBRSxDQUFNO1FBQUUsQ0FBTTtRQUFFLENBQU07UUFBRSxDQUFNO0lBQUEsQ0FBQztJQUVsRixHQUFHLENBQUNDLFFBQVEsR0FBR0gsU0FBUyxHQUFDLENBQUM7YUFFakJJLFVBQVUsQ0FBQ0MsS0FBSyxFQUFFQyxLQUFLLEVBQUMsQ0FBQztRQUM5QkEsS0FBSyxJQUFJSCxRQUFRO1FBRWpCLE1BQU0sNkVBQ0RMLG9FQUFhO1lBQWFTLEtBQUssRUFBRUYsS0FBSztXQUFuQkMsS0FBSzs7Ozs7SUFFakMsQ0FBQztJQUVELE1BQU0sNkVBQ0RFLENBQUc7UUFBQ0MsS0FBSyxFQUFFLENBQUNDO1lBQUFBLE9BQU8sRUFBRSxDQUFNO1FBQUEsQ0FBQztrQkFDeEJWLFNBQVMsR0FBQyxDQUFDLEtBQUcsQ0FBQyxHQUNaQyxTQUFTLENBQUNVLEdBQUcsQ0FBQ1AsVUFBVSxJQUV4QkYsU0FBUyxDQUFDUyxHQUFHLENBQUNQLFVBQVU7Ozs7OztBQUl4QyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdGFidWxlaXJvLy4vY29tcG9uZW50cy9MaW5oYVRhYnVsZWlyby9MaW5oYVRhYnVsZWlyby5qc3g/YmQzMyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgQ2FzYVRhYnVsZWlybyBmcm9tIFwiLi4vQ2FzYVRhYnVsZWlyby9DYXNhVGFidWxlaXJvXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMaW5oYVRhYnVsZWlybyh7bGluZVZhbHVlfSl7XHJcblxyXG4gICAgY29uc3QgY29sb3JTZXQxID0gW1wiI2ZmZlwiLCBcIiMwMDBcIiwgXCIjZmZmXCIsIFwiIzAwMFwiLCBcIiNmZmZcIiwgXCIjMDAwXCIsIFwiI2ZmZlwiLCBcIiMwMDBcIl07XHJcbiAgICBjb25zdCBjb2xvclNldDIgPSBbXCIjMDAwXCIsIFwiI2ZmZlwiLCBcIiMwMDBcIiwgXCIjZmZmXCIsIFwiIzAwMFwiLCBcIiNmZmZcIiwgXCIjMDAwXCIsIFwiI2ZmZlwiXTtcclxuXHJcbiAgICBsZXQga2V5VmFsdWUgPSBsaW5lVmFsdWUqODtcclxuXHJcbiAgICBmdW5jdGlvbiByZW5kZXJMaW5lKENvbG9yLCBpbmRleCl7XHJcbiAgICAgICAgaW5kZXggKz0ga2V5VmFsdWU7XHJcblxyXG4gICAgICAgIHJldHVybihcclxuICAgICAgICAgICAgPENhc2FUYWJ1bGVpcm8ga2V5PXtpbmRleH0gY29sb3I9e0NvbG9yfS8+XHJcbiAgICAgICAgKVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybihcclxuICAgICAgICA8ZGl2IHN0eWxlPXt7ZGlzcGxheTogXCJmbGV4XCJ9fT5cclxuICAgICAgICAgICAge2xpbmVWYWx1ZSUyPT09MD9cclxuICAgICAgICAgICAgICAgIGNvbG9yU2V0MS5tYXAocmVuZGVyTGluZSlcclxuICAgICAgICAgICAgICAgIDpcclxuICAgICAgICAgICAgICAgIGNvbG9yU2V0Mi5tYXAocmVuZGVyTGluZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxufSJdLCJuYW1lcyI6WyJDYXNhVGFidWxlaXJvIiwiTGluaGFUYWJ1bGVpcm8iLCJsaW5lVmFsdWUiLCJjb2xvclNldDEiLCJjb2xvclNldDIiLCJrZXlWYWx1ZSIsInJlbmRlckxpbmUiLCJDb2xvciIsImluZGV4IiwiY29sb3IiLCJkaXYiLCJzdHlsZSIsImRpc3BsYXkiLCJtYXAiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/LinhaTabuleiro/LinhaTabuleiro.jsx\n");

/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Home)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_LinhaTabuleiro_LinhaTabuleiro__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/LinhaTabuleiro/LinhaTabuleiro */ \"./components/LinhaTabuleiro/LinhaTabuleiro.jsx\");\n\n\nfunction Home() {\n    const linesArray = [\n        0,\n        1,\n        2,\n        3,\n        4,\n        5,\n        6,\n        7\n    ];\n    function renderTable(index) {\n        return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_LinhaTabuleiro_LinhaTabuleiro__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n            lineValue: index\n        }, index, false, {\n            fileName: \"D:\\\\Nova_pasta\\\\pen_drive\\\\backup\\\\ionic\\\\Jorge\\\\tabuleiro\\\\pages\\\\index.js\",\n            lineNumber: 9,\n            columnNumber: 7\n        }, this));\n    }\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"board\",\n        children: linesArray.map(renderTable)\n    }, void 0, false, {\n        fileName: \"D:\\\\Nova_pasta\\\\pen_drive\\\\backup\\\\ionic\\\\Jorge\\\\tabuleiro\\\\pages\\\\index.js\",\n        lineNumber: 14,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUF3RTtBQUV6RCxRQUFRLENBQUNDLElBQUksR0FBRyxDQUFDO0lBRTlCLEtBQUssQ0FBQ0MsVUFBVSxHQUFHLENBQUM7QUFBQSxTQUFDO0FBQUUsU0FBQztBQUFFLFNBQUM7QUFBRSxTQUFDO0FBQUUsU0FBQztBQUFFLFNBQUM7QUFBRSxTQUFDO0FBQUUsU0FBQztJQUFBLENBQUM7YUFFbENDLFdBQVcsQ0FBQ0MsS0FBSyxFQUFDLENBQUM7UUFDMUIsTUFBTSw2RUFDSEosaUZBQWM7WUFBYUssU0FBUyxFQUFFRCxLQUFLO1dBQXZCQSxLQUFLOzs7OztJQUU5QixDQUFDO0lBRUQsTUFBTSw2RUFDSEUsQ0FBRztRQUFDQyxTQUFTLEVBQUMsQ0FBTztrQkFDbkJMLFVBQVUsQ0FBQ00sR0FBRyxDQUFDTCxXQUFXOzs7Ozs7QUFHakMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3RhYnVsZWlyby8uL3BhZ2VzL2luZGV4LmpzP2JlZTciXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExpbmhhVGFidWxlaXJvIGZyb20gXCIuLi9jb21wb25lbnRzL0xpbmhhVGFidWxlaXJvL0xpbmhhVGFidWxlaXJvXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XG5cbiAgY29uc3QgbGluZXNBcnJheSA9IFswLCAxLCAyLCAzLCA0LCA1LCA2LCA3XTtcblxuICBmdW5jdGlvbiByZW5kZXJUYWJsZShpbmRleCl7XG4gICAgcmV0dXJuKFxuICAgICAgPExpbmhhVGFidWxlaXJvIGtleT17aW5kZXh9IGxpbmVWYWx1ZT17aW5kZXh9Lz5cbiAgICApXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9hcmRcIj5cbiAgICAgIHtsaW5lc0FycmF5Lm1hcChyZW5kZXJUYWJsZSl9XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJuYW1lcyI6WyJMaW5oYVRhYnVsZWlybyIsIkhvbWUiLCJsaW5lc0FycmF5IiwicmVuZGVyVGFibGUiLCJpbmRleCIsImxpbmVWYWx1ZSIsImRpdiIsImNsYXNzTmFtZSIsIm1hcCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/index.js\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.js"));
module.exports = __webpack_exports__;

})();